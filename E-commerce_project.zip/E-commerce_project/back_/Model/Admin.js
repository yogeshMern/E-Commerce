const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema(
  {
    userName: {
      type: String,
      trim: true,
      required: [true, "a admin must have a username!"],
      unique: [true, "a admin must have a unique username!"],
      minlength: [5, "a admin username must have a atleast 5 character!"],
    },
    email: {
      type: String,
      trim: true,
      required: [true, "a admin must have a email Id!"],
      unique: [true, "a admin must have unique email Id!"],
    },
    password: {
      type: String,
      required: [true, "a admin must provide a strong password!"],
      minlength: [5, "a admin password must have a atleast 5 character!"],
    },
    role: {
      type: String,
      required: true,
      enum: ["admin", "super_admin"],
      default: "admin",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Admin", adminSchema);
