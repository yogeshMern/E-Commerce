const Razorpay = require("razorpay");
console.log(1111111111111111, process.env.RAZORPAY_API_KEY);

const instance = new Razorpay({
  key_id: process.env.RAZORPAY_API_KEY,
  key_secret: process.env.RAZORPAY_SECRET_KEY,
});

module.exports = instance;
