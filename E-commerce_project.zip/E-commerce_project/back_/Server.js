const app = require("./App");
const Database = require("./Database/database");

const PORT = process.env.PORT || 3000;

Database();

app.listen(PORT, () => console.log(`Server is running on ${PORT}...⚡`));
