const Admin = require("../Model/Admin");
const User = require("../Model/User");
const Product = require("../Model/Product");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const catchAsync = require("../Utils/catchAsync");
const AppError = require("../Utils/appError");

exports.registerAdminRole = catchAsync(async (req, res, next) => {
  const { userName, email, password, role } = req.body;
  if (role !== "admin" && role !== "super_admin") {
    return res.status(400).json({ message: "Invalid role provided!" });
  }

  if (!userName || !email || !password) {
    return res.status(200).json({ message: "All fields are required!" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const adminExist = await Admin.findOne({ $or: [{ email }, { userName }] });
  const adminExist2 = await User.findOne({ $or: [{ email }, { userName }] });
  if (adminExist || adminExist2) {
    return next(
      new AppError("Admin with this email or username already exists!", 200)
    );
  }

  const newAdmin = await Admin.create({
    userName,
    email,
    password: hashedPassword,
    role,
  });

  const token = jwt.sign({ userId: newAdmin._id }, process.env.JWT_SECRET_KEY, {
    expiresIn: "10h",
  });

  res.status(201).json({
    success: true,
    message: `${
      newAdmin.role === "super_admin" ? "Super Admin" : "Admin"
    } Registered Successfully`,
    data: newAdmin,
    token,
  });
});

exports.loginAdminRole = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res
      .status(200)
      .json({ message: "Please provide email or password!" });
  }

  const existUser = await Admin.findOne({ email }).select("+password").lean();
  if (!existUser) {
    return next(new AppError("User not Registered with this email!", 200));
  }

  const isVaidPAssword = await bcrypt.compare(password, existUser.password);
  if (!isVaidPAssword) {
    return res.status(400).json({ message: "Invalid email or password!" });
  }

  const token = jwt.sign({ __id: existUser._id }, process.env.JWT_SECRET_KEY, {
    expiresIn: "10h",
  });

  delete existUser.password;

  res.cookie("authToken", token, {
    expires: new Date(Date.now() + 30 * 24 * 3600000),
    path: "/",
    secure: false, // Use "true" for HTTPS
    // sameSite: "next", // For cross-site cookies
    signed: true,
  });
  res.status(200).json({
    succes: true,
    message: `${
      existUser.role === "super_admin" ? "Super Admin" : "Admin"
    } Login successfuly`,
    data: existUser,
    token,
  });
});

exports.logoutAdminRole = catchAsync(async (req, res, next) => {
  res.clearCookie("authToken");

  res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
});

exports.getAllAdmin = catchAsync(async (req, res, next) => {
  const data = await Admin.find({ role: "admin" });
  res.status(200).json({
    status: "succes",
    message: `${data ? "Admin fetched Successfully" : "Data not found!"}`,
    toalAdmin: data.length,
    data: data,
  });
});

exports.removeAdmin = catchAsync(async (req, res, next) => {
  const _id = req.params.id;

  if (!_id) {
    return next(new AppError("Id is not defined!"), 400);
  }

  const admin = await Admin.findByIdAndDelete({ _id });

  res.status(200).json({
    status: "succes",
    message: "Admin removed Successfully",
  });
});

exports.getAllProduct = catchAsync(async (req, res, next) => {
  const products = await Product.find();

  if (products.length === 0) {
    return res.status(200).json({ message: "Products not found!" });
  }

  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;
  const productsWithImage = products.map((product) => ({
    ...product.toObject(),
    productImage: `${imgUrl}${product.productImage}`,
  }));

  res.status(200).json({
    success: true,
    message: "Product List fetched Successfully",
    productLength: productsWithImage.length,
    data: productsWithImage,
  });
});

exports.updateProductDetails = catchAsync(async (req, res, next) => {
  const { productName, newPrice, description } = req.body;
  const _id = req.params.id;

  if (!_id) {
    next(new AppError("Id is not defined!"), 400);
  }

  const data = await Product.findByIdAndUpdate(
    { _id },
    { productName, newPrice, description },
    {
      new: true,
      runValidator: true,
    }
  );

  res.status(200).json({
    success: true,
    message: "Updation successfuly!",
    data,
  });
});

exports.deleteProduct = catchAsync(async (req, res, next) => {
  const _id = req.params.id;
  if (!_id) {
    next(new AppError("Id is not defined!"), 400);
  }

  const data = await Product.findByIdAndDelete({ _id });
  if (!data) {
    next(new AppError("Data not found!"), 404);
  }

  res.status(200).json({
    success: true,
    message: "Product Deleted successfuly!",
  });
});

// exports.countProducts = catchAsync(async (req, res, next) => {
//   const count = await Product.countDocuments();
//   const randomSkip = Math.floor(Math.random() * count);
//   const moreProduct = await Product.find().skip(randomSkip).limit(8);

//   const totalProduct = await Product.find();
//   const popularInWomens = await Product.find({ category: "women" }).limit(4);
//   const totalMensProduct = await Product.find({ category: "men" });
//   const totalWomenProduct = await Product.find({ category: "women" });
//   const totalKidsProduct = await Product.find({ category: "kid" });

//   const newCollection = [];
//   const categories = ["women", "men", "kid"];
//   for (const category of categories) {
//     const categoryProducts = await Product.find({ category }).limit(4);
//     newCollection.push(categoryProducts);
//   }

//   const data = [
//     { length: moreProduct.length, label: "More Product" },
//     { length: totalProduct.length, label: "Total Product" },
//     { length: popularInWomens.length, label: "Popular in Women" },
//     { length: newCollection.length, label: "New Collection" },
//     { length: totalMensProduct.length, label: "Total Men's Product" },
//     { length: totalWomenProduct.length, label: "Total Women's Product" },
//     { length: totalKidsProduct.length, label: "Total Kid's Product" },
//   ];

//   res.status(200).json({
//     status: "succes",
//     message: "Product count fetched successfully",
//     data,
//   });
// });

exports.countProducts = catchAsync(async (req, res, next) => {
  const count = await Product.countDocuments();
  // const randomSkip = Math.floor(Math.random() * count);

  const [totalProduct, totalMensProduct, totalWomenProduct, totalKidsProduct] =
    await Promise.all([
      Product.find(),
      Product.find({ category: "men" }),
      Product.find({ category: "women" }),
      Product.find({ category: "kid" }),
    ]);

  // const popularInWomens = await Product.aggregate([
  //   { $match: { category: "women" } },
  //   { $limit: 4 },
  // ]);

  // const newCollection = await Promise.all([
  //   Product.aggregate([{ $match: { category: "women" } }, { $limit: 4 }]),
  //   Product.aggregate([{ $match: { category: "men" } }, { $limit: 4 }]),
  //   Product.aggregate([{ $match: { category: "kid" } }, { $limit: 4 }]),
  // ]);

  const data = [
    { length: totalProduct.length, label: "Total Product" },
    { length: totalMensProduct.length, label: "Men's Product" },
    { length: totalWomenProduct.length, label: "Women's Product" },
    { length: totalKidsProduct.length, label: "Kid's Product" },
  ];

  res.status(200).json({
    status: "success",
    message: "Product count fetched successfully",
    data,
  });
});

exports.addProducts = catchAsync(async (req, res, next) => {
  const { productName, newPrice, oldPrice, category, description, rating } =
    req.body;

  const productImage = req.file.filename;
  if (!productName || !newPrice || !category || !description) {
    return res.status(400).json({ message: "All fields are required!" });
  }
  if (!productImage) {
    return res.status(400).json({ message: "Product Image missing!" });
  }

  const data = await Product.create({
    productName,
    newPrice,
    category,
    description,
    productImage,
  });

  res.status(201).json({
    success: true,
    message: "Product created successfuly!",
    data,
  });
});
