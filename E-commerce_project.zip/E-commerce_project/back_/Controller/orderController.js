const Razorpay = require("razorpay");
const Order = require("../Model/Order");
const catchAsync = require("../Utils/catchAsync");
const AppError = require("../Utils/appError");
const crypto = require("crypto");
const mongoose = require("mongoose");

exports.createOrder = catchAsync(async (req, res, next) => {
  const { productId, isCOD, email, contact, quantity, newPrice } = req.body;

  if (!productId || !email || !contact || !quantity || !newPrice) {
    return res.status(400).json({
      status: "fail",
      message: "All fields are required!",
    });
  }

  if (isCOD) {
    const codOrder = await Order.create({
      productId,
      COD: isCOD,
      email,
      contact,
      quantity,
      newPrice,
    });

    return res.status(201).json({
      status: "success",
      message: "COD Order Placed",
      data: codOrder,
    });
  } else {
    const instance = new Razorpay({
      key_id: process.env.RAZORPAY_API_KEY,
      key_secret: process.env.RAZORPAY_SECRET_KEY,
    });

    const options = {
      amount: newPrice * 100, // Razorpay expects the amount in paise (smallest currency unit)
      currency: "INR",
    };

    const order = await instance.orders.create(options);

    if (!order) {
      return res.status(500).json({
        status: "fail",
        message: "Razorpay order creation failed",
      });
    }

    const onlinePayment = await Order.create({
      productId,
      COD: isCOD,
      email,
      contact,
      quantity,
      newPrice,
      razorpay_order_id: order.id, // Storing the razorpay_order_id
    });

    return res.status(200).json({
      status: "success",
      message: "Razorpay order created",
      data: {
        order,
        onlinePayment,
      },
    });
  }
});

exports.paymentVerification = catchAsync(async (req, res, next) => {
  const { razorpay_payment_id, razorpay_order_id, razorpay_signature } =
    req.body;

  const body = razorpay_order_id + "|" + razorpay_payment_id;

  const generated_signature = crypto
    .createHmac("sha256", process.env.RAZORPAY_SECRET_KEY)
    .update(body.toString())
    .digest("hex");

  // console.log("sign recieved", razorpay_signature);
  // console.log("sign genrated", generated_signature);

  const isAuthentic = generated_signature === razorpay_signature;
  // if (isAuthentic) {
  //   await Order.create({
  //     razorpay_payment_id,
  //     razorpay_order_id,
  //     razorpay_signature,
  //   });
  //   res.redirect("http://localhost:5173/profile");
  // } else {
  //   res.status(400).json({
  //     status: "false",
  //     message: "Payment verification failed",
  //   });
  // }
  if (isAuthentic) {
    const updatedOrder = await Order.findOneAndUpdate(
      { razorpay_order_id },
      {
        razorpay_payment_id,
        razorpay_signature,
      },
      { new: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({
        status: "fail",
        message: "Order not found",
      });
    }

    // res.status(200).json({
    //   status: "success",
    //   messsage: "verified payment",
    // });
    res.redirect("http://localhost:5173/profile");
  } else {
    res.status(400).json({
      status: "false",
      message: "Payment verification failed",
    });
  }
});

exports.getKey = catchAsync(async (req, res, next) => {
  res.status(200).json({
    success: true,
    key: process.env.RAZORPAY_API_KEY,
  });
});

exports.viewOrder = catchAsync(async (req, res, next) => {
  const { userEmail } = req.query;
  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;

  const data = await Order.aggregate([
    {
      $match: { email: userEmail },
    },
    {
      $lookup: {
        from: "products",
        localField: "productId",
        foreignField: "_id",
        as: "productDetails",
      },
    },
    {
      $unwind: "$productDetails",
    },
    {
      $project: {
        quantity: 1,
        COD: 1,
        contact: 1,
        newPrice: 1,
        order_date: 1,
        email: 1,
        productImage: {
          $concat: [imgUrl, "$productDetails.productImage"],
        },
        productName: "$productDetails.productName",
        productPrice: "$productDetails.productPrice",
      },
    },
  ]);

  res.status(200).json({
    status: "success",
    message: "Fetched Order Details Successfully",
    data,
  });
});

exports.cancelOrder = catchAsync(async (req, res, next) => {
  const { id } = req.params;

  // Check if the id is a valid MongoDB ObjectId
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({
      status: "fail",
      message: "Invalid order ID",
    });
  }

  // Find and delete the order by id
  const order = await Order.findByIdAndDelete(id);

  // If the order does not exist
  if (!order) {
    return res.status(404).json({
      status: "fail",
      message: "Order not found",
    });
  }

  // Successful deletion
  res.status(200).json({
    status: "success",
    message: "Order has been canceled!",
  });
});
