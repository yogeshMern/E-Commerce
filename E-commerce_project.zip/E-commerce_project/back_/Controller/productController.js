const catchAsync = require("../Utils/catchAsync");
const AppError = require("../Utils/appError");
const Product = require("../Model/Product");

exports.createProduct = catchAsync(async (req, res, next) => {
  const { productName, newPrice, oldPrice, category, description, rating } =
    req.body;
  const productImage = req.file.filename;
  if (!productName || !newPrice || !category || !description) {
    return res.status(400).json({ message: "All fields are required!" });
  }
  if (!productImage) {
    return res.status(400).json({ message: "Product Image missing!" });
  }

  // const existingProduct = await Product.findOne({ productName });
  // if (existingProduct) {
  //   next(new AppError("Product already exist!"), 400);
  // }

  const data = await Product.create({
    productName,
    newPrice,
    category,
    description,
    productImage,
  });

  res.status(201).json({
    success: true,
    message: "Product created successfuly!",
    data,
  });
});

// exports.getAllProduct = catchAsync(async (req, res, next) => {
//   const products = await Product.find();
//   if (products.length === 0) {
//     return res.status(404).json({ message: "Products not found!" });
//   }

//   const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;
//   const productsWithImage = products.map((product) => ({
//     ...product.toObject(),
//     productImage: `${imgUrl}${product.productImage}`,
//   }));

//   res.status(200).json({
//     success: true,
//     message: "Product List",
//     data: productsWithImage,
//   });
// });

exports.getAllProduct = catchAsync(async (req, res, next) => {
  // const page = parseInt(req.query.page) || 1; // Current page number, default to 1
  // const productLimit = 6; // Number of products per page

  const filter = {};

  if (req.query.minPrice && req.query.maxPrice) {
    filter.newPrice = { $gte: req.query.minPrice, $lte: req.query.maxPrice };
  } else if (req.query.minPrice) {
    filter.newPrice = { $gte: req.query.minPrice };
  } else if (req.query.maxPrice) {
    filter.newPrice = { $lte: req.query.maxPrice };
  }

  if (req.query.rating) {
    filter.rating = { $lte: req.query.rating };
  }

  let sortOption = {};
  if (req.query.sortByPrice === "lowToHigh") {
    sortOption = { newPrice: 1 };
  } else if (req.query.sortByPrice === "highToLow") {
    sortOption = { newPrice: -1 };
  }

  if (req.query.productName) {
    // filter.name = { $regex: req.query.name, $options: "1" };
    const escapedPattern = req.query.productName.replace(
      /[-[\]{}()*+?.,\\^$|#\s]/g,
      "\\$&"
    );
    filter.productName = { $regex: escapedPattern, $options: "i" };
  }

  // const totalProducts = await Product.countDocuments(filter);
  // const totalPages = Math.ceil(totalProducts / productLimit);
  // const skipProduct = (page - 1) * productLimit;

  const products = await Product.find(filter).sort(sortOption);
  // .skip(skipProduct)
  // .limit(productLimit);

  if (products.length === 0) {
    return res.status(200).json({ message: "Products not found!" });
  }

  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;
  const productsWithImage = products.map((product) => ({
    ...product.toObject(),
    productImage: `${imgUrl}${product.productImage}`,
  }));

  res.status(200).json({
    success: true,
    message: "Product List fetched Successfully",
    // page,
    // totalPages,
    productLength: productsWithImage.length,
    data: productsWithImage,
  });
});

exports.getAllProducts = catchAsync(async (req, res, next) => {
  const page = parseInt(req.query.page) || 1; // Current page number, default to 1
  const productLimit = 6; // Number of products per page

  const filter = {};

  if (req.query.minPrice && req.query.maxPrice) {
    filter.newPrice = { $gte: req.query.minPrice, $lte: req.query.maxPrice };
  } else if (req.query.minPrice) {
    filter.newPrice = { $gte: req.query.minPrice };
  } else if (req.query.maxPrice) {
    filter.newPrice = { $lte: req.query.maxPrice };
  }

  if (req.query.rating) {
    filter.rating = { $lte: req.query.rating };
  }

  let sortOption = {};
  if (req.query.sortByPrice === "lowToHigh") {
    sortOption = { newPrice: 1 };
  } else if (req.query.sortByPrice === "highToLow") {
    sortOption = { newPrice: -1 };
  }

  if (req.query.productName) {
    // filter.name = { $regex: req.query.name, $options: "1" };
    const escapedPattern = req.query.productName.replace(
      /[-[\]{}()*+?.,\\^$|#\s]/g,
      "\\$&"
    );
    filter.productName = { $regex: escapedPattern, $options: "i" };
  }

  const totalProducts = await Product.countDocuments(filter);
  const totalPages = Math.ceil(totalProducts / productLimit);
  const skipProduct = (page - 1) * productLimit;

  const products = await Product.find(filter)
    .sort(sortOption)
    .skip(skipProduct)
    .limit(productLimit);

  if (products.length === 0) {
    return res.status(200).json({ message: "Products not found!" });
  }

  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;
  const productsWithImage = products.map((product) => ({
    ...product.toObject(),
    productImage: `${imgUrl}${product.productImage}`,
  }));

  res.status(200).json({
    success: true,
    message: "Product List fetched Successfully",
    // page,
    // totalPages,
    productLength: productsWithImage.length,
    data: productsWithImage,
  });
});

exports.updateProductDetails = catchAsync(async (req, res, next) => {
  const _id = req.params.id;
  const body = req.body;
  if (!_id) {
    next(new AppError("Id is not defined!"), 400);
  }

  const data = await Product.findByIdAndUpdate({ _id }, body, {
    new: true,
    runValidator: true,
  });

  if (!data) {
    next(new AppError("Data not found!"), 404);
  }

  res.status(200).json({
    success: true,
    message: "Updation successfuly!",
    data,
  });
});

exports.deleteProduct = catchAsync(async (req, res, next) => {
  const _id = req.params.id;
  if (!_id) {
    next(new AppError("Id is not defined!"), 400);
  }

  const data = await Product.findByIdAndDelete({ _id });
  if (!data) {
    next(new AppError("Data not found!"), 404);
  }

  res.status(200).json({
    success: true,
    message: "Product Deleted successfuly!",
  });
});

exports.getSingleProduct = catchAsync(async (req, res, next) => {
  const id = req.params.id;
  if (!id) {
    next(new AppError("Id is not defined!"), 400);
  }

  const data = await Product.findById(id);
  if (!data) {
    next(new AppError("Product not found!"), 404);
  }

  res.status(200).json({
    success: true,
    message: "Single product!",
    data,
  });
});

exports.popularInWomens = catchAsync(async (req, res, next) => {
  // const data = await Product.find({ category: "women" }).limit(4);

  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;

  const data = await Product.aggregate([
    {
      $match: { category: "women" },
    },
    {
      $project: {
        _id: 1,
        productName: 1,
        newPrice: 1,
        oldPrice: 1,
        category: 1,
        rating: 1,
        productImage: {
          $concat: [imgUrl, "$productImage"],
        },
        description: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    },
    {
      $limit: 4,
    },
  ]);

  if (!data) {
    return res.status(200).json({ message: "data not found!", data: [] });
  }

  res.status(200).json({
    success: true,
    messgae: "Womens Category Product!",
    data,
  });
});

// exports.newCollections = catchAsync(async (req, res, next) => {
//   const categories = ["women", "men", "kid"];
//   const products = [];

//   for (const category of categories) {
//     const categoryProducts = await Product.find({ category }).limit(2);
//     products.push(...categoryProducts);
//   }

//   if (products.length === 0) {
//     return res.status(200).json({ message: "data not found!", data: [] });
//   }

//   res.status(200).json({
//     success: true,
//     message: "New Collections!",
//     data: products,
//   });
// });

exports.newCollections = catchAsync(async (req, res, next) => {
  const categories = ["women", "men", "kid"];
  const products = [];

  for (const category of categories) {
    const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;
    const categoryProducts = await Product.find({ category }).limit(4);

    const productsWithImage = categoryProducts.map((product) => ({
      ...product.toObject(),
      productImage: `${imgUrl}${product.productImage}`,
    }));

    products.push(...productsWithImage);
  }

  if (products.length === 0) {
    return res.status(404).json({ message: "Data not found!", data: [] });
  }

  res.status(200).json({
    success: true,
    message: "New Collections!",
    data: products,
  });
});

exports.moreProducts = catchAsync(async (req, res, next) => {
  const imgUrl = `${req.protocol}://${req.get("host")}/products_images/`;

  const data = await Product.aggregate([
    { $sample: { size: 8 } },
    {
      $project: {
        _id: 1,
        productName: 1,
        newPrice: 1,
        oldPrice: 1,
        category: 1,
        rating: 1,
        productImage: {
          $concat: [imgUrl, "$productImage"],
        },
        description: 1,
        createdAt: 1,
        updatedAt: 1,
      },
    },
  ]);

  if (data.length === 0) {
    return res.status(404).json({ message: "Data not found!", data: [] });
  }

  res.status(200).json({
    success: true,
    message: "More Products!",
    data,
  });
});

// async function abc() {
//   let arr = [
//     3, 2.5, 4, 1, 3.2, 1.5, 4.5, 2, 3.7, 2.2, 4.3, 1.8, 3.9, 2.8, 4.2, 1.3, 3.5,
//     2.4, 4.1, 1.7, 3.8, 2.1, 4.4, 1.2, 3.6, 2.7, 4.7, 1.9, 3.4, 2.3, 4.9, 1.1,
//     3.3, 2.6, 4.6, 1.6, 3.1, 2.9, 4.8, 1.4, 3.2, 2.5, 4.5, 1.8, 3.9, 2.2, 4.3,
//     1.7, 3.8, 2.1, 4.4, 1.3, 3.6, 2.4, 4.1, 1.6, 3.5, 2.7,
//   ];
//   console.log("running");
//   const updateProd = await Product.find({}).lean();

//   const finalData = Promise.all(
//     updateProd.map(async (data, index) => {
//       const updateNew = await Product.findByIdAndUpdate(data._id, {
//         rating: arr[index],
//       });
//     })
//   );
//   console.log("updating");

//   if (finalData) {
//     console.log(finalData, "done");
//   } else {
//     console.log("false");
//   }

//   console.log("ends here");
// }
