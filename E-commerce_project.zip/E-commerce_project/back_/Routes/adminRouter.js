const express = require("express");
const router = express.Router();
const Controller = require("../Controller/adminController");
const auth = require("../Utils/authMiddleware");
const upload = require("../Common/upload");

router.post("/register_admin_role", Controller.registerAdminRole);
router.post("/login_admin_role", Controller.loginAdminRole);
router.post("/logout_admin_role", Controller.logoutAdminRole);

// super_admin router....................................................
router.get("/get_all_admin", Controller.getAllAdmin);
router.delete("/removed_admin_role/:id", Controller.removeAdmin);

// admin router..........................................................
router.get("/get_all_product", Controller.getAllProduct);
router.patch("/update_product_details/:id", Controller.updateProductDetails);
router.delete("/remove_product/:id", Controller.deleteProduct);

// count product length..................................................
router.get("/get_count", Controller.countProducts);

//Add Product
router.post(
  "/add_product",
  upload.single("productImage"),
  Controller.addProducts
);

module.exports = router;
