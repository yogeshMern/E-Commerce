const express = require("express");
const router = express.Router();
const Controller = require("../Controller/orderController");

router.post("/payment", Controller.createOrder);
router.get("/get_key", Controller.getKey);
router.post("/paymentvarification", Controller.paymentVerification);

router.get("/view_order", Controller.viewOrder);
router.delete("/remove_order/:id", Controller.cancelOrder);

module.exports = router;
