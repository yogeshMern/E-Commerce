const jwt = require("jsonwebtoken");

// module.exports = (req, res, next) => {
//   try {
//     let authHeader = req.signedCookies;
//     if (authHeader) {
//       let token = authHeader.authToken;
//       jwt.verify(token, process.env.JWT_SECRET_KEY, (err, data) => {
//         if (err) {
//           return res
//             .status(401)
//             .json({ message: "Please Login to access this resource!" });
//         }
//         // console.log(1111111111111111111111111, data);
//         req.user = data;
//         next();
//       });
//     } else {
//       return res
//         .status(401)
//         .json({ message: "You are not authorized to access this resource." });
//     }
//   } catch (error) {
//     res.status(500).json({
//       message: error,
//     });
//   }
// };

module.exports = (req, res, next) => {
  const authHeader = req.headers.authorization;

  // Check if authorization header exists and starts with "Bearer "
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      message: "No token provided or Invalid authorization header format",
    });
  }

  const token = authHeader.split(" ")[1]; // Extract token from "Bearer <token>"

  // Log token for debugging purposes (optional)
  // console.log("Token:", token);

  jwt.verify(token, process.env.JWT_SECRET_KEY, (err, decoded) => {
    if (err) {
      console.error("Token verification error:", err);
      // Handle specific errors (optional)
      if (err.name === "JsonWebTokenError") {
        // JWT malformed or invalid signature
        return res.status(401).json({ message: "Invalid token" });
      } else if (err.name === "TokenExpiredError") {
        // Expired token
        return res.status(401).json({ message: "Token expired" });
      } else {
        // Other errors
        return res.status(500).json({ message: "Internal server error" }); // Generic error for unexpected issues
      }
    }

    req.user = decoded; // Store decoded user data in request object
    // console.log("Decoded token:", decoded);
    next();
  });
};
