import Item from "../Components/Item";
import { useEffect, useState } from "react";
import { BASE_URL } from "../../env";
import Loader from "../Components/Loader";
import Filter from "./Filter";
import Axios from "axios";
import { SMALLER_THEN_ICONN, GREATER_THEN_ICONN } from "../Components/SVG";

const ExploreMore = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    minPrice: null,
    maxPrice: null,
    rating: null,
  });

  const fetchData = async () => {
    try {
      const params = {};
      if (filters.minPrice) params.minPrice = filters.minPrice.value;
      if (filters.maxPrice) params.maxPrice = filters.maxPrice.value;
      if (filters.rating) params.rating = filters.rating.value;

      // Convert params to query string
      const queryString = new URLSearchParams(params).toString();

      const res = await Axios.get(
        `${BASE_URL}/get-all-products?${queryString}`
      );
      setData(res?.data?.data);
    } catch (error) {
      console.log("All Products", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filters]);

  console.log("data", data);

  return (
    <div className="flex flex-col items-center gap-[10px] mb-[100px]">
      {/* <img className="block m-[30px] w-[85%]" src={props.banner} alt="banner" /> */}
      <div
        className=""
        style={{
          justifyContent: "space-between",
          display: "flex",
          width: "85%",
        }}
      >
        <p>
          <span className="font-semibold text-[12px]">Showing 1-12</span>
          <span className="text-[12px]">outOf 36 products</span>
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center w-full col-span-4">
          <Loader />
        </div>
      ) : (
        <div className="flex justify-center w-[85%]">
          <aside className="hidden py-2 md:block mt-10">
            <div className="sticky top-12 flex flex-col w-[350px]">
              <Filter setFilters={setFilters} />
            </div>
          </aside>

          <div className="mt-[50px] grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-[50px]">
            {data.map((ele, ind) => {
              return (
                <Item
                  key={ind}
                  id={ele?._id}
                  productName={ele?.productName}
                  productImage={ele?.productImage}
                  newPrice={ele?.newPrice}
                  oldPrice={ele?.oldPrice}
                  category={ele?.category}
                  description={ele?.description}
                  rating={ele?.rating}
                />
              );
            })}

            {/* Pagination Code .....................................................*/}
            <nav aria-label="Page navigation example">
              <ul className="inline-flex -space-x-px text-base h-10">
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-black bg-white border border-gray-500 rounded-s-lg hover:bg-gray-800 hover:text-white"
                  >
                    <SMALLER_THEN_ICONN />
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-black bg-white border border-gray-500 hover:bg-gray-800 hover:text-white"
                  >
                    1
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-black bg-white border border-gray-500 hover:bg-gray-800 hover:text-white"
                  >
                    2
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    aria-current="page"
                    className="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-black bg-white border border-gray-500 hover:bg-gray-800 hover:text-white"
                  >
                    3
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center px-4 h-10 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                  >
                    4
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="flex items-center justify-center px-4 h-10 ms-0 leading-tight text-black bg-white border border-gray-500 rounded hover:bg-gray-800 hover:text-white"
                  >
                    <GREATER_THEN_ICONN />
                  </a>
                </li>
              </ul>
            </nav>
            {/* Pagination Code .....................................................*/}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExploreMore;
