import Item from "../Components/Item";
import { useEffect, useState } from "react";
import Axios from "axios";
import { BASE_URL } from "../../env";
import Loader from "../Components/Loader";
import Filter from "./Filter";
import { Link } from "react-router-dom";
// import debounce from "lodash.debounce";

const ShopCategory = (props) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    minPrice: null,
    maxPrice: null,
    rating: null,
  });

  // Fetch initial set of products
  useEffect(() => {
    fetchData();
  }, [filters]);

  const fetchData = async () => {
    try {
      const params = {};
      if (filters.minPrice) params.minPrice = filters.minPrice.value;
      if (filters.maxPrice) params.maxPrice = filters.maxPrice.value;
      if (filters.rating) params.rating = filters.rating.value;

      // Convert params to query string
      const queryString = new URLSearchParams(params).toString();

      const res = await Axios.get(`${BASE_URL}/get-all-product?${queryString}`);
      setData(res?.data?.data);
    } catch (error) {
      console.log("All Products", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-[10px] mb-[100px]">
      <img className="block m-[30px] w-[85%]" src={props.banner} alt="banner" />
      <div
        className=""
        style={{
          justifyContent: "space-between",
          display: "flex",
          width: "85%",
        }}
      >
        <p>
          <span className="font-semibold text-[12px]">Showing 1-12</span>
          <span className="text-[12px]">outOf 36 products</span>
        </p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center w-full col-span-4">
          <Loader />
        </div>
      ) : (
        <div className="flex justify-center w-[85%]">
          <aside className="hidden py-2 md:block mt-10">
            <div className="sticky top-12 flex flex-col w-[350px]">
              <Filter setFilters={setFilters} />
            </div>
          </aside>

          <div className="mt-[50px] grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-[50px]">
            {data.map((ele, ind) => {
              if (props.category === ele?.category) {
                return (
                  <Item
                    key={ind}
                    id={ele?._id}
                    productName={ele?.productName}
                    productImage={ele?.productImage}
                    newPrice={ele?.newPrice}
                    oldPrice={ele?.oldPrice}
                    category={ele?.category}
                    description={ele?.description}
                    rating={ele?.rating}
                  />
                );
              } else {
                return null;
              }
            })}
          </div>
        </div>
      )}

      <Link to="/exploreMore">
        <div className="hover:bg-gray-500 hover:text-white flex justify-center items-center m-[120px] w-[233px] h-[69px] rounded-[75px] bg-[#ededed] text-[#787878] text-[18px] font-semibold cursor-pointer transition duration-300 ease-in-out">
          Explore More
        </div>
      </Link>
    </div>
  );
};

export default ShopCategory;
