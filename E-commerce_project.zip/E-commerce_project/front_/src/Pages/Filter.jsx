import React, { useEffect, useState } from "react";
import Select from "react-select";

const Filter = ({ setFilters }) => {
  const [minPrice, setMinPrice] = useState(null);
  const [maxPrice, setmaxPrice] = useState(null);
  const [rating, setRating] = useState(null);

  // use this function when You are seaching or filtering data by click on a button
  // const handleApplyFilter = () => {
  //   const filters = {
  //     minPrice: minPrice ? minPrice.value : null,
  //     maxPrice: maxPrice ? maxPrice.value : null,
  //     val: val ? val.value : null,
  //     rating: rating ? rating.val : null,
  //   };

  //   setFilters(filters);
  // };

  useEffect(() => {
    setFilters({ minPrice, maxPrice, rating });
  }, [minPrice, maxPrice, rating, setFilters]);

  const arr = [
    { value: 100, label: "100" },
    { value: 200, label: "200" },
    { value: 300, label: "300" },
    { value: 400, label: "400" },
    { value: 500, label: "500" },
    { value: 600, label: "600" },
    { value: 700, label: "700" },
    { value: 800, label: "800" },
    { value: 900, label: "900" },
    { value: 1000, label: "1000" },
  ];

  return (
    <>
      <div className="w-full cursor-pointer mt-10">
        <ul className="w-[80%] m-auto text-[12px]">
          <li>Price</li>

          <li className="py-2 flex justify-between items-center">
            <Select
              options={arr}
              onChange={setMinPrice}
              value={minPrice}
              placeholder="Min"
            />
            <Select
              options={arr}
              onChange={setmaxPrice}
              value={maxPrice}
              placeholder="Max"
            />
          </li>
        </ul>

        <ul className="w-[80%] m-auto text-[12px] mt-10">
          <li>Ratings</li>
          <li className="py-2">
            <Select
              options={[
                { value: 1, label: "under 1 rating ⭐" },
                { value: 2, label: "under 2 rating ⭐⭐" },
                { value: 3, label: "under 3 rating ⭐⭐⭐" },
                { value: 4, label: "under 4 rating ⭐⭐⭐⭐" },
                { value: 5, label: "under 5 rating ⭐⭐⭐⭐⭐" },
              ]}
              onChange={setRating}
              value={rating}
              placeholder="Ratings"
            />
          </li>
        </ul>
      </div>
    </>
  );
};

export default Filter;
