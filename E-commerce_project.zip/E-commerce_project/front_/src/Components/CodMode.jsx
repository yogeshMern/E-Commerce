import { useNavigate } from "react-router-dom";

const CodMode = ({ data }) => {
  const navigate = useNavigate();
  const placeOrder = async () => {
    console.log("working........");
  };

  return <div className="text-black font-semibold text-2xl">CodMode</div>;
};

export default CodMode;
