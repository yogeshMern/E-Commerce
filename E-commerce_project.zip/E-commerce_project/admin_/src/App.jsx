import "./App.css";
import SideBar from "./components/Sidebar/SideBar";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Notfound from "./components/Notfound";
import Dashboard from "./pages/Dashboard";
import Admin from "./pages/Admin";
import Product from "./pages/Product";
import Order from "./pages/Order";
import Signout from "./pages/Signout";
import Viewproduct from "./components/Viewproduct";
import Addproduct from "./pages/Addproduct";

function App() {
  return (
    <Router>
      <SideBar>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/product" element={<Product />} />
          <Route path="/order" element={<Order />} />
          <Route path="/signout" element={<Signout />} />
          <Route path="/viewproduct" element={<Viewproduct />} />
          <Route path="/addproduct" element={<Addproduct />} />

          <Route path="*" element={<Notfound />} />
        </Routes>
      </SideBar>
    </Router>
  );
}

export default App;
