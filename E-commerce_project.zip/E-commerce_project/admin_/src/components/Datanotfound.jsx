import { FaRegSadCry } from "react-icons/fa";

const Datanotfound = () => {
  return (
    <div className="w-full flex items-center gap-5">
      <h1 className="text-2xl text-center">Admin data not found!</h1>
      <FaRegSadCry className="text-3xl" />
    </div>
  );
};

export default Datanotfound;
