import React, { useEffect, useState } from "react";
import { FaEdit, MdDeleteForever } from "./Icon";
import { useLocation } from "react-router-dom";
import { Confirm } from "./Confirmbox";
import Loader from "./Loader";
import Editproduct from "../pages/Editproduct";

const Viewproduct = () => {
  const location = useLocation();
  const [data, setData] = useState();
  const [open, setOpen] = useState(false);
  const [openEditForm, setOpenEditForm] = useState(false);
  const [storeData, setStoreData] = useState();

  // useEffect(() => {
  //   setData(location?.state?.data);
  // }, [location?.state]);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (location.state && location.state.data) {
        setData(location.state.data);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [location.state]);

  return (
    <>
      {data ? (
        <>
          <div className="w-full">
            <div className="ml-[30px] text-black flex items-center justify-between">
              <h1 className="text-[50px] font-bold text-shadow-2xl">
                Product Details
                <hr className="w-[150px] h-[6px] border rounded-[6px] bg-green-800" />
              </h1>

              {/* Product Edit Form ...........................................*/}
              {openEditForm ? (
                <Editproduct
                  setOpen={setOpenEditForm}
                  // fetchingData={fetchingPorduct}
                  data={storeData}
                />
              ) : null}
              {/* Product Edit Form ...........................................*/}

              {data !== undefined ? (
                <div className="flex gap-2">
                  <div className="flex justify-evenly items-center gap-2 border-2 border-gray-200 px-4 py-2 rounded-md transition-colors duration-300 hover:bg-gray-500 hover:text-white cursor-pointer">
                    <FaEdit
                      className="text-[25px]"
                      onClick={() => {
                        setOpenEditForm(true);
                        setStoreData(data);
                      }}
                    />
                  </div>
                  <div
                    onClick={() => setOpen(true)}
                    className="flex justify-evenly items-center gap-2 border-2 border-gray-200 px-4 py-2 rounded-md transition-colors duration-300 hover:bg-gray-500 hover:text-white cursor-pointer"
                  >
                    <MdDeleteForever className="text-[25px]" />
                  </div>
                </div>
              ) : null}
            </div>

            <div className="max-w-[1200px] ml-[30px] w-full mt-16 px-4">
              <div className="flex justify-around flex-wrap" key={data?._id}>
                <div className="max-w-[500px] min-w-[290px] overflow-hidden m-4">
                  <img
                    src={data?.productImage}
                    alt="product_image"
                    className="w-full h-full max-h-[400px] object-cover"
                  />
                </div>
                <div className="max-w-[500px] min-w-[290px] m-4">
                  <p className="text-[12px]">{data?.category}</p>
                  <div className="flex justify-between mb-4 mt-2">
                    <h2 className="text-md uppercase font-semibold break-all">
                      {data?.productName}
                    </h2>
                    <span className="flex gap-2">
                      <p className="text-green-600 font-semibold ">
                        ${data?.newPrice}
                      </p>
                      <p className="text-gray-400 line-through">
                        ${data?.oldPrice}
                      </p>
                    </span>
                  </div>
                  <div className="text-[15px] mb-4 max-h-[200px] overflow-auto flex justify-between items-center">
                    <p>Rating</p>
                    <p>{data?.rating}⭐</p>
                  </div>
                  <div className="text-[15px] mb-4 max-h-[200px] overflow-auto flex justify-between items-center">
                    <p>Creation Date</p>
                    <p>{data?.createdAt.split("T")[0]}</p>
                  </div>
                  <p className="text-[12px] mb-4">{data?.description}</p>
                </div>
              </div>
            </div>
          </div>

          {open && <Confirm data={data} setOpen={setOpen} action={"Product"} />}
        </>
      ) : (
        <div className="mt-[250px] ml-[400px]">
          <Loader />
        </div>
      )}
    </>
  );
};

export default Viewproduct;
