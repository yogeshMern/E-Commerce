import Axios from "axios";
import { BASE_URL } from "../../URL";
import { MdClose, RiDeleteBin6Line } from "./Icon";
import { useNavigate } from "react-router-dom";

export const Confirmbox = ({ data, fetchingData, setOpen, action, url }) => {
  const remove = async (id) => {
    try {
      const res = await Axios.delete(`${BASE_URL}/${url}/${id}`);
      if (res?.status === 200) {
        fetchingData();
      }
      setOpen(false);
    } catch (error) {
      console.log("Admin Delete Error!", error.message);
    }
  };

  return (
    <div
      className="fixed inset-0 p-4 flex flex-wrap justify-center items-center w-full h-full z-[1000] overflow-auto font-[sans-serif]"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      aria-hidden="true"
      aria-modal="true"
      role="dialog"
    >
      <div className="w-full max-w-md bg-white shadow-lg rounded-md p-6 relative">
        <MdClose
          onClick={() => setOpen(false)}
          className="text-[25px] cursor-pointer shrink-0 fill-black hover:fill-red-500 float-right"
        />
        <div className="my-8 text-center">
          <RiDeleteBin6Line className="text-[50px] fill-red-500 inline" />
          <h4 className="text-xl font-semibold mt-6">
            Are you sure you want to delete this {action} ?
          </h4>
          <p className="text-sm text-gray-800 mt-4">
            {data.userName || data.productName}
          </p>
        </div>
        <div className="flex justify-around">
          <button
            type="button"
            className="px-14 py-2.5 rounded-md text-white text-sm font-semibold border-none outline-none bg-red-500 hover:bg-red-600 active:bg-red-500"
            onClick={() => remove(data._id)}
          >
            Delete
          </button>
          <button
            type="button"
            className="px-14 py-2.5 rounded-md text-black text-sm font-semibold border-none outline-none bg-gray-200 hover:bg-gray-300 active:bg-gray-200"
            onClick={() => setOpen(false)}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export const Confirm = ({ data, setOpen, action }) => {
  const navigate = useNavigate();

  const removeProduct = async (id) => {
    try {
      const res = await Axios.delete(`${BASE_URL}/remove_product/${id}`);
      if (res?.status === 200) {
        setOpen(false);
      }
      navigate("/product");
    } catch (error) {
      console.log("Admin Delete Error!", error.message);
    }
  };
  return (
    <div
      className="fixed inset-0 p-4 flex flex-wrap justify-center items-center w-full h-full z-[1000] overflow-auto font-[sans-serif]"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      aria-hidden="true"
      aria-modal="true"
      role="dialog"
    >
      <div className="w-full max-w-md bg-white shadow-lg rounded-md p-6 relative">
        <MdClose
          onClick={() => setOpen(false)}
          className="text-[25px] cursor-pointer shrink-0 fill-black hover:fill-red-500 float-right"
        />
        <div className="my-8 text-center">
          <RiDeleteBin6Line className="text-[50px] fill-red-500 inline" />
          <h4 className="text-xl font-semibold mt-6">
            Are you sure you want to delete this {action} ?
          </h4>
        </div>
        <div className="flex justify-around">
          <button
            type="button"
            className="px-14 py-2.5 rounded-md text-white text-sm font-semibold border-none outline-none bg-red-500 hover:bg-red-600 active:bg-red-500"
            onClick={() => removeProduct(data._id)}
          >
            Delete
          </button>
          <button
            type="button"
            className="px-14 py-2.5 rounded-md text-black text-sm font-semibold border-none outline-none bg-gray-200 hover:bg-gray-300 active:bg-gray-200"
            onClick={() => setOpen(false)}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
