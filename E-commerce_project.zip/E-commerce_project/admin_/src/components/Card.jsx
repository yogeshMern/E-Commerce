import { TbClover } from "./Icon";

const Card = (props) => {
  return (
    <div className="w-[240px] shadow-xl border-2 border-red-100 bg-black h-auto rounded-[10px] transition-colors duration-300 hover:bg-green-800">
      <div className="flex justify-evenly items-center h-auto">
        <div className="text-white text-[50px]">
          <TbClover />
        </div>
        <p className="text-[80px] text-white">{props ? props.count : 0}</p>
      </div>
      <p className="text-white text-center text-[18px]">
        {props ? props.text : "Data Not Found"}
      </p>
    </div>
  );
};

export default Card;
