import {
  RiAdminFill,
  RiDeleteBin6Line,
  RiLogoutCircleRFill,
} from "react-icons/ri";
import { MdDeleteForever, MdClose, MdAdminPanelSettings } from "react-icons/md";
import { TbClover } from "react-icons/tb";
import { GiEvilLove } from "react-icons/gi";
import { PiBoxingGloveFill } from "react-icons/pi";
import { AiOutlineProduct } from "react-icons/ai";
import { BsCartCheck } from "react-icons/bs";
import {
  FaEdit,
  FaEye,
  FaPlus,
  FaUpload,
  FaHome,
  FaArrowAltCircleRight,
  FaArrowAltCircleLeft,
} from "react-icons/fa";

export {
  RiAdminFill,
  MdDeleteForever,
  TbClover,
  GiEvilLove,
  PiBoxingGloveFill,
  FaEdit,
  FaEye,
  FaPlus,
  MdClose,
  RiDeleteBin6Line,
  FaUpload,
  FaHome,
  FaArrowAltCircleRight,
  FaArrowAltCircleLeft,
  MdAdminPanelSettings,
  RiLogoutCircleRFill,
  AiOutlineProduct,
  BsCartCheck,
};
