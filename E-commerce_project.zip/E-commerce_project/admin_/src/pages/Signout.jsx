const Signout = () => {
  return <div className="text-3xl grid place-items-center">Signout</div>;
};

export default Signout;
