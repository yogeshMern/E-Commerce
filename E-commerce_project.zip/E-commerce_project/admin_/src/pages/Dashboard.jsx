import Card from "../components/Card";
import React, { useState, useEffect } from "react";
import Axios from "axios";
import { BASE_URL } from "../../URL";
import Loader from "../components/Loader";
import Chart from "./Chart";

const Dashboard = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchingDashboardData();
  }, []);

  const fetchingDashboardData = async () => {
    try {
      const res = await Axios.get(`${BASE_URL}/get_count`);
      setData(res?.data?.data);
      setLoading(false);
    } catch (err) {
      console.log("Error Dashboard!", err.message);
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      <h1 className="ml-[30px] text-black text-[50px] font-bold text-shadow-2xl">
        Dashboard
        <hr className="w-[200px] h-[6px] border rounded-[6px] bg-black" />
      </h1>
      <div className="mt-10 ml-[30px]">
        {loading ? (
          <Loader />
        ) : (
          <div className="m-auto grid lg:grid-cols-4 lg:gap-10">
            {data?.map((d, ind) => {
              return <Card text={d.label} count={d.length} key={ind} />;
            })}
          </div>
        )}

        {loading ? null : (
          <div className="mt-10">
            <Chart />
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
