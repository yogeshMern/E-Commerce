import React, { useState } from "react";
import { FaUpload, MdClose } from "../components/Icon";
import Axios from "axios";
import { toast } from "react-hot-toast";
import { BASE_URL } from "../../URL";
import { useNavigate } from "react-router-dom";

const Addproduct = () => {
  const [image, setImage] = useState(null);
  const [data, setData] = useState({
    productName: "",
    newPrice: "",
    category: "",
    oldPrice: "",
    rating: "",
    productImage: null,
    description: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
      setData({ ...data, productImage: file });
    }
  };

  const createProduct = async () => {
    if (
      !data?.productName ||
      !data?.newPrice ||
      !data?.category ||
      !data?.productImage ||
      !data?.description
    ) {
      toast.error("Please fill up all the fields");
      return;
    }
    try {
      const formData = new FormData();
      formData.append("productName", data?.productName);
      formData.append("newPrice", data?.newPrice);
      formData.append("category", data?.category);
      formData.append("oldPrice", data?.oldPrice);
      formData.append("rating", data?.rating);
      formData.append("description", data?.description);
      formData.append("productImage", data?.productImage);

      const res = await Axios.post(`${BASE_URL}/add_product`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      if (res?.data?.success) {
        setData({
          productName: "",
          newPrice: "",
          category: "",
          oldPrice: "",
          rating: "",
          productImage: null,
          description: "",
        });
        setImage(null);
        navigate("/product");
      }
    } catch (error) {
      console.log("Add Product Error", error.message);
      toast.error("Failed to add product");
    }
  };

  return (
    <>
      <div className="w-full">
        <div className="ml-[30px] text-black flex items-center justify-between">
          <h1 className="text-[50px] font-bold text-shadow-2xl">
            Add Product
            <hr className="w-[200px] h-[6px] border rounded-[6px] bg-black" />
          </h1>
        </div>
      </div>
      <div className="w-full">
        <div className="w-[90%] mt-10 ml-[30px] sm:ml-0 sm:w-full sm:px-4 lg:w-[90%] lg:ml-[30px]">
          <div className="px-2">
            <label
              htmlFor="productname"
              className="block mb-2 text-[12px] font-bold text-gray-900"
            >
              Product Name
            </label>
            <input
              type="text"
              name="productName"
              value={data.productName}
              onChange={handleChange}
              id="productname"
              className="py-1 w-full bg-gray-50 border border-gray-300 text-gray-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
              placeholder="Enter product name"
              required
            />
          </div>

          <div className="mt-5 flex flex-wrap gap-2 justify-between px-2">
            <div className="w-full sm:w-[calc(33%-8px)]">
              <label
                htmlFor="category"
                className="block mb-2 text-[12px] font-bold text-gray-900"
              >
                Category
              </label>
              <select
                id="category"
                name="category"
                value={data.category}
                onChange={handleChange}
                className="w-full bg-gray-50 py-[3px] border border-gray-300 text-gray-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
                required
              >
                <option>Select category</option>
                <option value="men">Men</option>
                <option value="women">Women</option>
                <option value="kid">Kid</option>
              </select>
            </div>
            <div className="w-full sm:w-[calc(33%-8px)]">
              <label
                htmlFor="oldprice"
                className="block mb-2 text-[12px] font-bold text-gray-900"
              >
                Old Price
              </label>
              <input
                type="number"
                name="oldPrice"
                value={data.oldPrice}
                onChange={handleChange}
                id="oldprice"
                className="w-full bg-gray-50 py-1 border border-gray-300 text-gray-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
                placeholder="Enter old price"
              />
            </div>
            <div className="w-full sm:w-[calc(33%-8px)]">
              <label
                htmlFor="newprice"
                className="block mb-2 text-[12px] font-bold text-gray-900"
              >
                New Price
              </label>
              <input
                type="number"
                name="newPrice"
                value={data.newPrice}
                onChange={handleChange}
                id="newprice"
                className="w-full bg-gray-50 py-1 border border-gray-300 text-gray-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
                placeholder="Enter new price"
                required
              />
            </div>
          </div>

          <div className="mt-5 px-2">
            <label
              htmlFor="description"
              className="block mb-2 text-[12px] font-bold text-gray-900"
            >
              Description
            </label>
            <textarea
              id="description"
              name="description"
              value={data.description}
              onChange={handleChange}
              placeholder="Enter product description"
              className="bg-gray-50 py-2 border border-gray-300 text-gray-800 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
              required
            />
          </div>

          <div className="mt-5 px-2">
            <label
              htmlFor="upload"
              className="block mb-2 text-[12px] font-bold text-gray-900"
            >
              Product Image
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 flex justify-center items-center cursor-pointer">
              <input
                type="file"
                id="upload"
                name="productImage"
                className="hidden"
                onChange={handleImageUpload}
              />
              <label
                htmlFor="upload"
                className="flex flex-col items-center justify-center h-[150px] w-full"
              >
                {image ? (
                  <div className="flex items-center">
                    <img
                      src={image}
                      alt="Product"
                      className="h-[150px] w-auto"
                    />
                    <MdClose
                      onClick={() => {
                        setImage(null);
                        setData({ ...data, productImage: null });
                      }}
                      className="text-[30px] cursor-pointer"
                    />
                  </div>
                ) : (
                  <>
                    <FaUpload className="text-[30px] text-gray-500" />
                    <span className="text-gray-600">Click to upload</span>
                  </>
                )}
              </label>
            </div>
          </div>

          <div className="mt-1 px-2">
            <button
              type="button"
              onClick={createProduct}
              className="hover:bg-gray-800 hover:text-white font-bold w-full text-[10px] border border-gray-500 rounded-md py-2"
            >
              Add Product
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Addproduct;
