import { MdDeleteForever } from "../components/Icon";
import { useEffect, useState } from "react";
import Axios from "axios";
import { BASE_URL } from "../../URL";
import Loader from "../components/Loader";
import Datanotfound from "../components/Datanotfound";
import { Confirmbox } from "../components/Confirmbox";

const Admin = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [selectedAdmin, setSelectedAdmin] = useState(null);

  useEffect(() => {
    fetchingAdminList();
  }, []);

  const fetchingAdminList = async () => {
    try {
      const res = await Axios.get(`${BASE_URL}/get_all_admin`);
      setData(res?.data?.data);
      setLoading(false);
    } catch (error) {
      console.log("Admin list Error", error.message);
      setLoading(false);
    }
  };

  const handleDeleteClick = (id) => {
    setSelectedAdmin(id);
    setOpen(true);
  };

  return (
    <div className="w-full">
      <h1 className="ml-[30px] text-black text-[50px] font-bold text-shadow-2xl">
        Admin List
        <hr className="w-[200px] h-[6px] border rounded-[6px] bg-black" />
      </h1>
      <div className="mt-10 ml-[30px]">
        {loading ? (
          <Loader />
        ) : data.length ? (
          <div className="relative overflow-x-auto">
            <table className="w-full min-w-max">
              <thead className="text-xs text-gray-700 uppercase bg-white border">
                <tr>
                  <th scope="col" className="px-10 py-3 text-center">
                    S.NO
                  </th>
                  <th scope="col" className="px-10 py-3 text-center">
                    Username
                  </th>
                  <th scope="col" className="px-10 py-3 text-center">
                    Email
                  </th>
                  <th scope="col" className="px-10 py-3 text-center">
                    Role
                  </th>
                  <th scope="col" className="px-10 py-3 text-center">
                    Creation Date
                  </th>
                  <th scope="col" className="px-10 py-3 text-center">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody>
                {data.map((e, ind) => (
                  <tr key={ind} className="bg-white border-b text-black">
                    <th scope="row" className="px-10 py-4 font-medium">
                      {ind + 1}.
                    </th>
                    <td className="px-10 py-4 text-center">{e?.userName}</td>
                    <td className="px-10 py-4 text-center">{e?.email}</td>
                    <td className="px-10 py-4 text-center">
                      {e?.role === "admin" ? "Admin" : "admin"}
                    </td>
                    <td className="px-10 py-4 text-center">
                      {e?.createdAt.split("T")[0]}
                    </td>
                    <td className="px-12 py-4 text-center text-red-600 text-xl">
                      <MdDeleteForever onClick={() => handleDeleteClick(e)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Datanotfound />
        )}
      </div>
      {open && selectedAdmin && (
        <Confirmbox
          data={selectedAdmin}
          fetchingData={fetchingAdminList}
          setOpen={setOpen}
          action={"Admin"}
          url={"removed_admin_role"}
        />
      )}
    </div>
  );
};

export default Admin;
