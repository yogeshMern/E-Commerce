import React, { useState, useEffect } from "react";
import { MdDeleteForever, FaEdit, FaEye, FaPlus } from "../components/Icon";
import { BASE_URL } from "../../URL";
import Axios from "axios";
import Loader from "../components/Loader";
import Datanotfound from "../components/Datanotfound";
import { Link, useNavigate } from "react-router-dom";
import { Confirmbox } from "../components/Confirmbox";
import Editproduct from "./Editproduct";

const Product = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [openEditForm, setOpenEditForm] = useState(false);
  const [product, setProduct] = useState();
  const navigate = useNavigate();

  useEffect(() => {
    fetchingPorduct();
  }, []);

  const fetchingPorduct = async () => {
    try {
      const res = await Axios.get(`${BASE_URL}/get_all_product`);
      setData(res?.data?.data);
      setLoading(false);
    } catch (error) {
      console.log("Error fetching Product", error.message);
      setLoading(false);
    }
  };

  const truncateText = (text, maxLength) => {
    if (!text) {
      return "N/A";
    }
    return text.length > maxLength ? `${text.slice(0, maxLength)}...` : text;
  };

  const sendState = (data) => {
    navigate("/viewproduct", { state: { data } });
  };

  const handleDeleteClick = (id) => {
    setSelectedProduct(id);
    setOpen(true);
  };

  return (
    <>
      <div className="w-full">
        <div className="ml-[30px] text-black flex items-center justify-between">
          <h1 className="text-[50px] font-bold text-shadow-2xl">
            Product
            <hr className="w-[150px] h-[6px] border rounded-[6px] bg-black" />
          </h1>

          {data?.length ? (
            <Link to="/addproduct">
              <div className="flex justify-evenly items-center gap-2 border-2 border-gray-200 px-4 py-2 rounded-md transition-colors duration-300 hover:bg-gray-500 hover:text-white cursor-pointer">
                Add <FaPlus className="text-[25px]" />
              </div>
            </Link>
          ) : null}
        </div>

        {/* Product Edit Form ...........................................*/}
        {openEditForm ? (
          <Editproduct
            setOpen={setOpenEditForm}
            fetchingData={fetchingPorduct}
            data={product}
          />
        ) : null}
        {/* Product Edit Form ...........................................*/}

        <div className="mt-10 ml-[30px]">
          {loading ? (
            <Loader />
          ) : data?.length ? (
            <div
              className="relative overflow-x-auto"
              style={{ maxHeight: "490px", maxWidth: "100%" }}
            >
              <table className="w-full min-w-max">
                <thead className="text-xs text-gray-700 uppercase bg-white border cursor-pointer">
                  <tr>
                    <th scope="col" className="px-2 py-4 text-center">
                      S.NO
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Image
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Product Name
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Price
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Rating
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Category
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Creation Date
                    </th>
                    <th scope="col" className="px-2 py-4 text-center">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((e, ind) => {
                    return (
                      <tr key={ind} className="bg-white border-b text-black">
                        <th scope="row" className="px-6 py-4">
                          {ind < 1 ? 1 : ++ind}.
                        </th>
                        <td className="text-center">
                          <img
                            src={e?.productImage}
                            alt={e?.productName}
                            className="w-10 h-10 rounded-full"
                          />
                        </td>
                        <td className="px-4 py-4 text-center">
                          {truncateText(e?.productName, 50)}
                        </td>
                        <td className="px-4 py-4 text-center text-green-500">
                          ${e?.newPrice}
                        </td>
                        <td className="px-4 py-4 text-center">{e?.rating}⭐</td>
                        <td className="px-4 py-4 text-center">
                          {e?.category}'s
                        </td>
                        <td className="px-4 py-4 text-center">
                          {e?.createdAt.split("T")[0]}
                        </td>
                        <td className="px-4 py-4 text-center text-md gap-1 flex justify-evenly items-center cursor-pointer">
                          <FaEye
                            className="text-blue-600"
                            onClick={() => sendState(e)}
                          />
                          <FaEdit
                            className="text-orange-600"
                            onClick={() => {
                              setOpenEditForm(true);
                              setProduct(e);
                            }}
                          />
                          <MdDeleteForever
                            className="text-red-600"
                            onClick={() => handleDeleteClick(e)}
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <Datanotfound />
          )}
        </div>
      </div>

      {/* Delete Confirm Box ..........................................*/}
      {open && selectedProduct && (
        <Confirmbox
          data={selectedProduct}
          fetchingData={fetchingPorduct}
          setOpen={setOpen}
          action={"Product"}
          url={"remove_product"}
        />
      )}
      {/* Delete Confirm Box ..........................................*/}
    </>
  );
};

export default Product;
