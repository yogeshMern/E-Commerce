import React, { useEffect, useState } from "react";
import { Pie, Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, Title } from "chart.js";
import Axios from "axios";
import { BASE_URL } from "../../URL";
import Loader from "../components/Loader";

// Register the components
ChartJS.register(ArcElement, Tooltip, Legend, Title);

const Chart = () => {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchingDashboardData();
  }, []);

  const fetchingDashboardData = async () => {
    try {
      const res = await Axios.get(`${BASE_URL}/get_count`);
      const apiData = res.data.data;

      // Transforming data for Chart.js
      const chartLabels = apiData.map((item) => item.label);
      const chartData = apiData.map((item) => item.length);

      setData({
        labels: chartLabels,
        datasets: [
          {
            data: chartData,
            backgroundColor: [
              "#FF6384",
              "#36A2EB",
              "#FFCE56",
              "#4BC0C0",
              "#9966FF",
              "#FF9F40",
            ],
            hoverBackgroundColor: [
              "#FF6384",
              "#36A2EB",
              "#FFCE56",
              "#4BC0C0",
              "#9966FF",
              "#FF9F40",
            ],
          },
        ],
      });

      setLoading(false);
    } catch (err) {
      console.log("Error fetching dashboard data!", err.message);
      setLoading(false);
    }
  };

  return (
    <div className="w-full">
      {loading ? (
        <div className="mt-[250px] ml-[400px]">
          <Loader />
        </div>
      ) : (
        <div className="flex items-center justify-between">
          <div className="w-[320px] h-[320px]">
            <Pie
              data={data}
              className="border"
              options={{
                responsive: true,
                maintainAspectRatio: false,
                color: "black",
                plugins: {
                  legend: {
                    position: "bottom",
                  },
                  title: {
                    display: true,
                    text: "Product Distribution",
                    color: "black",
                  },
                },
              }}
            />
          </div>

          <div className="w-[320px] h-[320px]">
            <Doughnut
              data={data}
              className="border"
              options={{
                responsive: true,
                maintainAspectRatio: false,
                color: "black",
                plugins: {
                  legend: {
                    position: "bottom",
                  },
                  title: {
                    display: true,
                    text: "Product Distribution",
                    color: "black",
                  },
                },
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Chart;
