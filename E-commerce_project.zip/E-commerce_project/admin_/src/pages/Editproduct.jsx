import { useState } from "react";
import { MdClose, FaEdit } from "../components/Icon";
import Axios from "axios";
import { BASE_URL } from "../../URL";

const Editproduct = ({ data, setOpen, fetchingData }) => {
  const [value, setValue] = useState(data);

  const handleChange = (e) => {
    setValue({ ...data, [e.target.name]: e.target.value });
  };

  const submitUpdatedDetails = async (id) => {
    try {
      const res = await Axios.patch(
        `${BASE_URL}/update_product_details/${id}`,
        value
      );
      if (res?.status === 200) {
        fetchingData();
      }
      setOpen(false);
    } catch (error) {
      console.log("Product Update Error!", error.message);
    }
  };

  const handleClose = () => setOpen(false);

  return (
    <div
      className="fixed inset-0 p-4 flex justify-center items-center w-full h-full z-[1000] overflow-auto font-[sans-serif]"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      aria-hidden="true"
      aria-modal="true"
      role="dialog"
    >
      <div className="w-full max-w-md bg-white shadow-lg rounded-md p-6 relative">
        <MdClose
          onClick={handleClose}
          className="text-[25px] cursor-pointer shrink-0 fill-black hover:fill-red-500 absolute top-4 right-4"
        />
        <div className="text-center">
          <FaEdit className="text-[50px] fill-green-500 inline" />
          <h4 className="text-xl font-semibold mt-6">
            Product Details Update Form
          </h4>
          <div className="text-sm text-gray-800 mt-4 space-y-4">
            <div className="flex flex-col">
              <label className="mb-1 text-left">Name</label>
              <input
                type="text"
                name="productName"
                value={value?.productName}
                onChange={(e) => handleChange(e)}
                placeholder="Enter product name"
                className="border-2 border-gray-200 rounded-lg p-2 text-[14px]"
              />
            </div>

            <div className="flex flex-col">
              <label className="mb-1 text-left">Price</label>
              <input
                type="number"
                name="newPrice"
                value={value?.newPrice}
                onChange={(e) => handleChange(e)}
                placeholder="Enter new price"
                className="border-2 border-gray-200 rounded-lg p-2 text-[14px]"
              />
            </div>

            <div className="flex flex-col">
              <label className="mb-1 text-left">Description</label>
              <textarea
                type="text"
                name="description"
                value={value?.description}
                onChange={(e) => handleChange(e)}
                placeholder="Enter product description"
                className="border-2 border-gray-200 rounded-lg p-2 text-[14px] h-24 resize-none"
              />
            </div>
          </div>
        </div>
        <div className="flex justify-around mt-6">
          <button
            onClick={() => submitUpdatedDetails(data?._id)}
            type="button"
            className="px-14 py-2.5 rounded-md text-white text-sm font-semibold border-none outline-none bg-green-600 hover:bg-green-700 active:bg-green-500"
          >
            Update
          </button>
          <button
            onClick={handleClose}
            type="button"
            className="px-14 py-2.5 rounded-md text-black text-sm font-semibold border-none outline-none bg-gray-200 hover:bg-gray-300 active:bg-gray-200"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default Editproduct;
