const Order = () => {
  return <div className="text-3xl grid place-items-centertitle"> Order</div>;
};

export default Order;
