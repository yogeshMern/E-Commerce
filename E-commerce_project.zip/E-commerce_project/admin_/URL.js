export const BASE_URL = "http://localhost:8000/admin/api/v1";
